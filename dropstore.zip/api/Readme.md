Dropstore backend
